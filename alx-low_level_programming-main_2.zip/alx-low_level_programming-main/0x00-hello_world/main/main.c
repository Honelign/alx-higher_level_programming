#include <stdio.h>

/**
 *  main - Entry point
 *
 * Return: Always 0 (Success)
*/

int main(void)
{
return (0);
}
