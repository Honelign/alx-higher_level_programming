#include "../variadic_functions.h"

/**
 * main - check the code for ALX School students.
 *
 * Return: Always 0.
*/
int main(void)
{
	print_strings(", ", 2, "Jay", "Django");
	return (0);
}
