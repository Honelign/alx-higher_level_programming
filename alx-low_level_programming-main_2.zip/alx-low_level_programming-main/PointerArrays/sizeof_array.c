#include <stdio.h>

/**
 * main - printing the sizeof an array
 *
 * Return: Always 0.
*/

int main(void)
{
	int array[10];

	printf("sizeof array: %lu\n", sizeof(array));
	return (0);
}
