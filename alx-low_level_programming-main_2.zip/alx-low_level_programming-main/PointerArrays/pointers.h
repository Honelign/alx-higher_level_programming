void modif_my_param(int *m);
void modif_my_char_var(char *cc, char ccc);
