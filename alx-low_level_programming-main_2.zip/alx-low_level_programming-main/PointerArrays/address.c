#include <stdio.h>

/**
 * main - addresses of variables
 *
 * Return: Always 0 (Success)
*/

int main(void)
{
	char c;
	int n;

	printf("Address of variable 'c' is %p\n", &c);
	printf("Address of variable 'n' is %p\n", &n);
	return (0);
}
