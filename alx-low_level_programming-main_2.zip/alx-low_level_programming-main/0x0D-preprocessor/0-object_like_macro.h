#ifndef _OBJECT_LIKE_MACRO_H
#define _OBJECT_LIKE_MACRO_H

#define SIZE 1024

#endif /* _OBJECT_LIKE_MACRO_H */
