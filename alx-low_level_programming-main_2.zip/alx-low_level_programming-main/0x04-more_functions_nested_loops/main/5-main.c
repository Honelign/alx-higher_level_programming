#include "../main.h"

/**
 * main - check the code for ALX School students
 *
 * Return: Always 0 (Success)
*/

int main(void)
{
	more_numbers();
	return (0);
}
