/**
 * mul - multiplies two integers
 *
 * @a: first input
 * @b: second input
 *
 * Return: return results
*/

int mul(int a, int b)
{
	return (a * b);
}
