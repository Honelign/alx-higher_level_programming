#include "../main.h"

/**
 * main - Entry point
 *
 * Description: check the code for ALX School students
 *
 * Return: Always 0 (Success)
*/

int main(void)
{
	print_alphabet();
	return (0);
}
