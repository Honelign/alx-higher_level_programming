#include"main.h"

/**
 * add - add two integers
 *
 * @a: first input
 * @b: second input
 *
 * Return: sum of a & b
*/

int add(int a, int b)
{
	int sum = a + b;

	return (sum);
}
